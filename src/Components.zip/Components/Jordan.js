import React from "react";
import JordanMatrix from "./math/JordanMatrix";
import { Container } from "react-dom";

function Jordan({data}){
    return(
        <Container>
            <h2>Мы смогли</h2>
            <Button>
                //здесь короче кнопочка при нажатии на которую запустится
                //JordanMatrix с параметрами, который пользователь в форме заполнил
            </Button>
        </Container>
    )
}